package com.example.InputDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InputDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
