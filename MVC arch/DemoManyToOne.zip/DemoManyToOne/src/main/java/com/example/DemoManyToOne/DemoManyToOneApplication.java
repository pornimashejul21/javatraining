package com.example.DemoManyToOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoManyToOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoManyToOneApplication.class, args);
	}

}
