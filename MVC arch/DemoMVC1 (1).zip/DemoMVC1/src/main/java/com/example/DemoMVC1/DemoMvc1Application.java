package com.example.DemoMVC1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMvc1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvc1Application.class, args);
	}

}
