package com.example.DemoMVC1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMvc1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
