package com.example.ManyToOneDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToOneDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
