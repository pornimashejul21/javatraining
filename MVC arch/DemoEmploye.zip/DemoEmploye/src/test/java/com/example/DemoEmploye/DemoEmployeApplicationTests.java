package com.example.DemoEmploye;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEmployeApplicationTests {

	@Test
	void contextLoads() {
	}

}
