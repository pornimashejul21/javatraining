package com.example.DemoUnsecure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoUnsecureApplicationTests {

	@Test
	void contextLoads() {
	}

}
