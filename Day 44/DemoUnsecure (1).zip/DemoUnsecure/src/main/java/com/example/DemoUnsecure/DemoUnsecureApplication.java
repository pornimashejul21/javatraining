package com.example.DemoUnsecure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoUnsecureApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoUnsecureApplication.class, args);
	}

}
