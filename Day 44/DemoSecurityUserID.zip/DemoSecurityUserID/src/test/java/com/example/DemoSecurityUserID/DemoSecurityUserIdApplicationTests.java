package com.example.DemoSecurityUserID;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSecurityUserIdApplicationTests {

	@Test
	void contextLoads() {
	}

}
