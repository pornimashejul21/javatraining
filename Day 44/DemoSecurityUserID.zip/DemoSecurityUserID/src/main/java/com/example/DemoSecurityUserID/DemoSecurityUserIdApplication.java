package com.example.DemoSecurityUserID;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSecurityUserIdApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSecurityUserIdApplication.class, args);
	}

}
